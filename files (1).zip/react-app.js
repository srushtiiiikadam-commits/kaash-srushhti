/* Kaash Enterprises | Srushhti Earthline – React: header, hero, sections, footer */
(function(){
var h=React.createElement,S=React.useState,E=React.useEffect;
var PH1='+919220636721',PH2='+919371890018',M1='kaashenterprises2711@gmail.com',M2='srushhtiearthline@gmail.com';

/* ---------- React: layout, hero, sections ---------- */
function Reveal(p){var r=React.useRef(null),s=S(false);
 E(function(){var o=new IntersectionObserver(function(e){if(e[0].isIntersecting){s[1](true);o.disconnect()}},{threshold:.12});o.observe(r.current);return function(){o.disconnect()}},[]);
 return h('div',{ref:r,className:'rv'+(s[0]?' in':'')+(p.className?' '+p.className:'')},p.children)}

function Head(){var o=S(false),a=S('home'),t=S(false);
 E(function(){var ids=['home','about','services','products','contact'];
  function f(){var y=window.scrollY+120,c='home';ids.forEach(function(i){var e=document.getElementById(i);if(e&&e.offsetTop<=y)c=i});a[1](c)}
  window.addEventListener('scroll',f);f();return function(){window.removeEventListener('scroll',f)}},[]);
 function tog(){var n=!t[0];t[1](n);document.documentElement.setAttribute('data-theme',n?'dark':'light')}
 var L=[['home','Home'],['about','About'],['services','Services'],['contact','Contact']];
 return h('header',null,h('div',{className:'wrap nav'},
  h('a',{href:'#home',className:'brand duo'},h('span',null,'KAASH',h('small',null,'ENTERPRISES')),h('i',{className:'sep'}),h('span',null,'SRUSHHTI',h('small',null,'EARTHLINE'))),
  h('button',{className:'burger','aria-label':'Menu',onClick:function(){o[1](!o[0])}},o[0]?'×':'☰'),
  h('nav',{className:'links'+(o[0]?' open':'')},
   L.map(function(l){return h('a',{key:l[0],href:'#'+l[0],className:a[0]===l[0]?'on':'',onClick:function(){o[1](false)}},l[1])}),
   h('button',{className:'theme','aria-label':'Toggle theme',onClick:tog},'◐'),
   h('a',{href:'#quote',className:'btn red',onClick:function(){o[1](false)}},'Get a Quote'))))}

function Hero(){return h('section',{id:'home',className:'hero'},h('div',{className:'plaid'}),
 h('div',{className:'wrap'},
  h('div',{className:'eyebrow'},'Thane · Maharashtra'),
  h('h1',null,'Uniforms with ',h('em',null,'character.')),
  h('span',{className:'tag'},'We design · We print · We embroider · We manufacture'),
  h('p',null,'Kaash Enterprises and Srushhti Earthline design and manufacture chef coats, cook shirts, vests, pants, aprons and kitchen accessories, plus uniforms for hotels, hospitals, schools, corporates and industry.'),
  h('div',{className:'cta btnrow'},h('a',{href:'#quote',className:'btn red'},'Get a Quote'),h('a',{href:'#services',className:'btn ghost'},'Explore Our Services'))))}

function About(){return h('section',{id:'about'},h('div',{className:'wrap'},
 h(Reveal,{className:'center'},h('div',{className:'eyebrow'},'About Us'),h('h2',{className:'title'},'Two names. One standard.'),
  h('p',{className:'sub'},'We are specialists in designer uniforms. Both companies offer the complete range of our work, and each order is handled personally from fabric selection to final dispatch.')),
 h('div',{className:'grid g2 div2'},
  [['Kaash Enterprises','Chef uniforms, kitchen wear and institutional uniforms, designed, printed, embroidered and manufactured to order.'],['Srushhti Earthline','Chef uniforms, kitchen wear and institutional uniforms, designed, printed, embroidered and manufactured to order.']].map(function(d){
   return h(Reveal,{key:d[0]},h('div',{className:'card'},h('div',{className:'eyebrow'},'Our Company'),h('h3',null,d[0]),h('p',null,d[1])))}))))}

var SV=[['✏️','We Design','Original and custom chef-wear patterns, with fabric and colour matched to your kitchen or brand.'],['🖨️','We Print & Embroider','Logos, names and designations applied cleanly on coats, shirts, aprons and caps.'],['🏭','We Manufacture','Bulk production of up to 18,000 pieces a month, in sizes XS to 4XL.'],['🏫','Institutional Uniforms','School, college, corporate, hospital, hotel, factory, lab, sports and security uniforms.']];
function Services(){return h('section',{id:'services',className:'alt'},h('div',{className:'wrap'},
 h(Reveal,{className:'center'},h('div',{className:'eyebrow'},'What we do'),h('h2',{className:'title'},'Our Services'),h('p',{className:'sub'},'Straightforward ways to get your team uniformed.')),
 h('div',{className:'grid g4'},SV.map(function(s){return h(Reveal,{key:s[1]},h('div',{className:'card'},h('div',{className:'ic'},s[0]),h('h3',null,s[1]),h('p',null,s[2])))}))))}

var PR=[['All','',''],['Chef Coats','Chef Coats (C10–C81)','s2','Double-breasted, side-closure and designer coats in white, black and colours. Twill 65/35 polycotton, XS–4XL.'],['Cook Shirts','Cook Shirts (S05–S18, U80–U81)','s1','Short-sleeve cook shirts with contrast collars, V-necks and snap closures.'],['Vests','Vests (V4–V7)','s4','Men’s and ladies’ black and burgundy vests for service staff.'],['Pants','Chef Pants (CP6–CP8, P40–P54)','s3','Elastic-waist, houndstooth, pinstripe, cargo and formal trousers.'],['Hats','Hats & Accessories (H.1–H.8)','s6','Chef hats, beanies, skull caps and neckerchiefs, including kids’ sizes.'],['Aprons','Aprons (A.2–A.26)','s5','Bib, bistro, waist and long aprons in cotton, denim, canvas and leather.'],['Knife Rolls','Chef Knife Rolls (A28–A30)','s2','Leather and PV matty knife rolls for carrying your tools.']];
function Products(){var f=S('All');
 var items=PR.slice(1).filter(function(p){return f[0]==='All'||p[0]===f[0]});
 return h('section',{id:'products',className:'work'},h('div',{className:'wrap'},
  
  h('div',{className:'tabs'},PR.map(function(p){return h('button',{key:p[0],className:'tab'+(f[0]===p[0]?' on':''),onClick:function(){f[1](p[0])}},p[0])})),
  h('div',{className:'grid g3'},items.map(function(p){return h('div',{key:p[0],className:'card'},h('div',{className:'swatch '+p[2]}),h('h3',null,p[1]),h('p',null,p[3]))}))))}

var ED=[['Premium Quality & Finish','Durable fabrics and careful tailoring for comfort and a polished look.'],['Customised Solutions','Designs aligned to your brand identity and operational needs.'],['Cost-Effective Pricing','Competitive pricing that never compromises on material or craftsmanship.'],['Bulk Production Capacity','Up to 18,000 pieces per month, delivered within agreed timelines.'],['Seamless Experience','A simple process from first enquiry to final delivery.'],['Dedicated Support','Responsive help after delivery for long-term partnerships.']];
function Edge(){return h('section',null,h('div',{className:'wrap'},
 h(Reveal,{className:'center'},h('div',{className:'eyebrow'},'Why choose us'),h('h2',{className:'title'},'Our Competitive Edge')),
 h('div',{className:'grid g3'},ED.map(function(e,i){return h(Reveal,{key:e[0]},h('div',{className:'card hex'},h('div',{className:'n'},'0'+(i+1)),h('div',null,h('h3',{style:{marginTop:0}},e[0]),h('p',null,e[1]))))}))))}

var ST=[['Enquire','Share your requirement via form, call or WhatsApp.'],['Design & Sample','We finalise fabric, colour and fit.'],['Production','Stitching and quality checks in bulk.'],['Delivery','Packed and dispatched on schedule.']];
function Process(){return h('section',{className:'alt'},h('div',{className:'wrap'},
 h(Reveal,{className:'center'},h('div',{className:'eyebrow'},'How it works'),h('h2',{className:'title'},'From enquiry to delivery')),
 h('div',{className:'grid g4'},ST.map(function(s,i){return h(Reveal,{key:s[0]},h('div',{className:'card'},h('div',{className:'hex'},h('span',{className:'n'},i+1)),h('h3',null,s[0]),h('p',null,s[1])))}))))}

function Contact(){return h('section',{id:'contact'},h('div',{className:'wrap'},
 h('div',{className:'center'},h('div',{className:'eyebrow'},'Contact'),h('h2',{className:'title'},'Let’s talk uniforms')),
 h('div',{className:'contact'},
  h('div',{className:'info'},
   h('p',null,h('b',null,'Office'),'Office no 306, Janki Nivas CHS,',h('br'),'Dr. Mosse Road, Thane West 400602'),
   h('p',null,h('b',null,'Phone'),h('a',{href:'tel:'+PH1},'+91 92206 36721'),' / ',h('a',{href:'tel:'+PH2},'+91 93718 90018')),
   h('p',null,h('b',null,'Email'),h('a',{href:'mailto:'+M1},M1),h('br'),h('a',{href:'mailto:'+M2},M2)),
   h('a',{className:'btn line',target:'_blank',rel:'noopener',href:'https://www.google.com/maps/search/?api=1&query=Janki+Nivas+CHS+Dr+Mosse+Road+Thane+West'},'View on Map')),
  h('div',{id:'vue-quote'}))))}

function Foot(){return h('footer',null,h('div',{className:'wrap'},
 h('div',{className:'fgrid'},
  h('div',null,h('div',{className:'brand'},'KAASH',h('small',null,'ENTERPRISES')),h('div',{className:'brand',style:{marginTop:14}},'SRUSHHTI',h('small',null,'EARTHLINE')),h('p',null,'Chef uniforms and institutional wear, made with care in Thane.')),
  h('div',null,h('h4',null,'Quick Links'),['Home','About','Services','Contact'].map(function(l){return h('a',{key:l,href:'#'+l.toLowerCase()},l)})),
  h('div',null,h('h4',null,'Get in touch'),h('p',null,'Office no 306, Janki Nivas CHS, Dr. Mosse Road, Thane West 400602'),h('a',{href:'tel:'+PH1},'+91 92206 36721'),h('a',{href:'tel:'+PH2},'+91 93718 90018'),h('a',{href:'mailto:'+M1},M1),h('a',{href:'mailto:'+M2},M2))),
 h('div',{className:'fb'},h('span',null,'© 2026 Kaash Enterprises · Srushhti Earthline. All rights reserved.'),h('button',{className:'top','aria-label':'Back to top',onClick:function(){window.scrollTo({top:0,behavior:'smooth'})}},'↑'))))}

function App(){return h(React.Fragment,null,h(Head),h('main',null,h(Hero),h(About),h(Services),h(Edge),h(Process),h('section',{id:'faq-wrap',className:'alt'},h('div',{className:'wrap'},h('div',{className:'center'},h('div',{className:'eyebrow'},'FAQ'),h('h2',{className:'title'},'Common questions')),h('div',{id:'vue-faq'}))),h(Contact)),h(Foot),
 h('a',{className:'wa',target:'_blank',rel:'noopener',href:'https://wa.me/919220636721'},'💬 WhatsApp'))}

ReactDOM.createRoot(document.getElementById('react-root')).render(h(App));
})();
