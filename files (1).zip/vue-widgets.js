/* Kaash Enterprises | Srushhti Earthline – Vue: FAQ accordion + quote form */
(function(){
function mount(){
 var f=document.getElementById('vue-faq'),q=document.getElementById('vue-quote');
 if(!f||!q){return setTimeout(mount,50)}
 Vue.createApp({data:function(){return{open:0,items:[
  {q:'Do you take bulk orders?',a:'Yes. Share your quantity, sizes and specifications and we will respond with a quote.'},
  {q:'Can you match our company colours and logo?',a:'We tailor fabric, colour and branding to your requirement, with samples before bulk production.'},
  {q:'Which industries do you serve?',a:'Hotels, restaurants and catering, hospitals, schools and colleges, corporates, factories, sports, labs, security and pharmaceutical companies.'},
  {q:'What sizes and colours are available?',a:'Most styles come in XS to 4XL, in different colours, in twill 65/35 polycotton.'},{q:'How do I place an enquiry?',a:'Use the quote form below, call us, or message us on WhatsApp.'}]}},
  template:'<div class="faq"><div v-for="(i,n) in items" :key="n" class="q" :class="{open:open===n}"><button @click="open=open===n?-1:n"><span>{{i.q}}</span><span class="pl">+</span></button><div class="a">{{i.a}}</div></div></div>'}).mount(f);
 Vue.createApp({data:function(){return{n:'',p:'',t:'Chef Coats',qty:'',m:'',err:''}},
  computed:{text:function(){return 'Hello, I would like a quote.\nName: '+this.n+'\nPhone: '+this.p+'\nProduct: '+this.t+'\nQuantity: '+this.qty+'\nDetails: '+this.m}},
  methods:{ok:function(){if(!this.n.trim()||this.p.replace(/\D/g,'').length<10){this.err='Please enter your name and a valid 10-digit phone number.';return false}this.err='';return true},
   wa:function(){if(this.ok())window.open('https://wa.me/919220636721?text='+encodeURIComponent(this.text),'_blank')},
   mail:function(){if(this.ok())window.location.href='mailto:'+'kaashenterprises2711@gmail.com'+'?subject='+encodeURIComponent('Quote request – '+this.t)+'&body='+encodeURIComponent(this.text)}},
  template:'<div class="formbox" id="quote"><h3 style="font-size:28px">Get a Quote</h3><div class="two"><div><label>Name</label><input v-model="n" autocomplete="name"></div><div><label>Phone</label><input v-model="p" type="tel" autocomplete="tel"></div></div><div class="two"><div><label>Product</label><select v-model="t"><option>Chef Coats</option><option>Cook Shirts</option><option>Vests</option><option>Chef Pants</option><option>Hats &amp; Accessories</option><option>Aprons</option><option>Knife Rolls</option><option>Other</option></select></div><div><label>Approx. quantity</label><input v-model="qty" inputmode="numeric"></div></div><label>Details</label><textarea rows="4" v-model="m"></textarea><div v-if="err" class="err">{{err}}</div><div class="cta" style="margin-top:20px"><button class="btn red" @click="wa">Send on WhatsApp</button><button class="btn line" @click="mail">Send by Email</button></div></div>'}).mount(q);
}
mount();
})();
